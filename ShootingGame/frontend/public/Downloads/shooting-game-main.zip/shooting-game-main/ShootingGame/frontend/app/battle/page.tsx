import BattleGround from "@/components/BattleGround";
export default function BattleGroundd() {
  return (
    <div>
      <BattleGround />
    </div>
  );
}
