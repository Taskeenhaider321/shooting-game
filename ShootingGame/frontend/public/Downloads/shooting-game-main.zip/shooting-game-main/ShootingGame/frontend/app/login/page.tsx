import Login from "@/components/Login";
export default function Loginn() {
  return (
    <div>
      <Login />
    </div>
  );
}
