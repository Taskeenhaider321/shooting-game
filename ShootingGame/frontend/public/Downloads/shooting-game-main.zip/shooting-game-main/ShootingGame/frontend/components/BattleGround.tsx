import React from "react";

const BattleGround: React.FC = () => {
  return (
    <body style={{display: "flex", alignItems: "center", justifyContent: "center"}}>
    <div >
      <div
        style={{
          position: "absolute",
          color: "white",
          fontSize: "10px",
          padding: "8px",
          fontFamily: "sans-serif",
          borderRadius: "10px",
          userSelect: "none",
          background: "pink",
        }}
      >
        <div style={{ marginBottom: "8px" }}>Leaderboard</div>
        <div id="playerLabels"></div>
      </div>
      <canvas></canvas>
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          position: "absolute",
          top: 0,
          right: 0,
          bottom: 0,
          left: 0,
        }}
      >
        <form id="usernameForm">
          <div style={{ textAlign: "center", marginTop: "8px" }}>
            <button
              style={{
                padding: "8px 20px",
                borderRadius: "100px",
                border: "none",
                backgroundImage: "linear-gradient(to right, rgb(6, 182, 212), rgb(59, 130, 246))",
                color: "white",
                cursor: "pointer",
              }}
            >
              Start!
            </button>
          </div>
        </form>
      </div>
    </div>
    </body>
  );
};

export default BattleGround;