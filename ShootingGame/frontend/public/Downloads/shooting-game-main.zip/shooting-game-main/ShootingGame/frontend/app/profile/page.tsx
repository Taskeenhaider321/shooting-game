import Profile from "@/components/Profile";
export default function Profilee() {
  return (
    <div>
      <Profile />
    </div>
  );
}
