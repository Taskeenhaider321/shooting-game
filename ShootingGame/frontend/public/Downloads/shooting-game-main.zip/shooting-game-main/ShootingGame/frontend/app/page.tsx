import Signup from "@/components/Signup";

export default function Home() {
  return (
    <div>
      <Signup />
    </div>
  );
}
